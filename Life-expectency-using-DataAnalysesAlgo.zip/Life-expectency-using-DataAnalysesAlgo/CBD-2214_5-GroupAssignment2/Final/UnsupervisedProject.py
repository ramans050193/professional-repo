#!/usr/bin/env python
# coding: utf-8

# In[1]:


#!/usr/bin/env python
# coding: utf-8
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Reading the data into a variable.
dataset = pd.read_csv(r'C:\ELORA\LAMBTON\SEM 1\CBD-2214-BigDataFundamentals\CBD_2214_5-GroupAssignment2\Live.csv')


# Print the first few(default - 5) values of the data.
print('Head: \n', dataset.head())


# In[2]:


# Print the information about the data(data-types and objects)
print(dataset.info())


# In[3]:


import seaborn as sns
import matplotlib.pyplot as plt

# Plotting graph showing null elements
sns.heatmap(pd.isna(dataset))
plt.show()


# In[4]:


# In[4]:


#Print null elements
dataset.isnull().sum()


# In[5]:


# Dropping the entirely null columns to clean the data.

dataset.drop(['Column1', 'Column2', 'Column3', 'Column4'], axis=1, inplace=True)

# Checking details after dropping the 4 columns
print(dataset.info())


# In[6]:


# Print the outline of data(count, mean, min, max,etc) rounding to 3 decimal places.
print('Describe: \n', round(dataset.describe(), 2))


# In[7]:


#There are 3 categorical variables in the dataset. we will explore them one by one.

# View how many different types of variables are there for status id.
len(dataset['status_id'].unique())


# In[8]:


# We can see that there are 6985 unique labels in the status_id variable.
#The total number of instances in the dataset is 7050. 
#So, it is approximately a unique identifier for each of the instances. 
#Thus this is not a variable that we can use. Hence, I will drop it.


# view how many different types of variables are there for status published.

len(dataset['status_published'].unique())


# In[9]:


# view how many different types of variables are there in status type

len(dataset['status_type'].unique())


# In[10]:


#We can see that there are 4 categories of labels in the status_type variable.

# As we have selected the unique parameter, we can drop the other two columns as it is not what we want to predict(Rephrase)
dataset.drop(['status_id', 'status_published'], axis=1, inplace=True)

# Checking details after dropping the 2 features
print(dataset.info())


# In[11]:



st_ax = dataset.status_type.value_counts().plot(kind='bar',
                                        figsize=(10,5),
                                        title="Status Type")
st_ax.set(xlabel="Status Type", ylabel="Count")


# In[12]:



from sklearn.preprocessing import LabelEncoder

# Assigning the features into variables
X = dataset
y = dataset['status_type']

# Converting parameters into numerical values for calculations
le = LabelEncoder()
X['status_type'] = le.fit_transform(X['status_type'])

y = le.transform(y)

print('X features: ',X.info())

print('X head: ',X.head())


# In[13]:


# Correlation graph

fig=plt.figure(figsize=(15,8))
sns.heatmap(dataset.corr(), annot=True, square=True)


# In[14]:



# Scaling of X attributes:

from sklearn.preprocessing import MinMaxScaler
print(type(X.columns))
print(type(X))
cols = X.columns
valuescaler = MinMaxScaler()
X = valuescaler.fit_transform(X)
X = pd.DataFrame(X, columns=[cols])

X.head()


# In[15]:


from sklearn.metrics import silhouette_score
from sklearn.cluster import KMeans
# Silhouette analysis
range_n_clusters = [2, 3, 4, 5, 6]

for num_clusters in range_n_clusters:
    
    # intialise kmeans
    kmeans = KMeans(n_clusters=num_clusters, max_iter=50)
    kmeans.fit(X)
    
    cluster_labels = kmeans.labels_
    
# silhouette score    
from yellowbrick.cluster import SilhouetteVisualizer

model = KMeans(5, random_state=1)
visualizer = SilhouetteVisualizer(model)
visualizer.fit(X)        # Fit the data to the visualizer
visualizer.show()


# In[16]:


# Clustering:
kmeans = KMeans(n_clusters=2, random_state=1) 

kmeans.fit(X)

print(kmeans)

# Cluster centroids
kmeans.cluster_centers_


# In[17]:


# Quality of model by classification

labels = kmeans.labels_

# check how many of the samples were correctly labeled
correct_labels = sum(y == labels)

#print('Cluster', kmeans)
print("Result: %d out of %d samples were correctly labeled." % (correct_labels, y.size))

# Print the Accuracy score of above model
print('Accuracy score: {0:0.2f}'. format(correct_labels/float(y.size)))


# In[18]:


# Checking with different clusters now, as we achieved a bad model resut from K=2. 

# 3 Clusters:

kmeans3 = KMeans(n_clusters=3, random_state=1)

kmeans3.fit(X)

# check how many of the samples were correctly labeled
labels = kmeans3.labels_

correct_labels = sum(y == labels)
print('Cluster', kmeans3)
print("Result: %d out of %d samples were correctly labeled." % (correct_labels, y.size))
print('Accuracy score: {0:0.2f}'. format(correct_labels/float(y.size)))


# In[19]:


# 4 Clusters:
kmeans4 = KMeans(n_clusters=4, random_state=1)

kmeans4.fit(X)

# check how many of the samples were correctly labeled
labels = kmeans4.labels_

correct_labels = sum(y == labels)
print('Cluster', kmeans4)
print("Result: %d out of %d samples were correctly labeled." % (correct_labels, y.size))
print('Accuracy score: {0:0.2f}'. format(correct_labels/float(y.size)))


# In[20]:


# 5 clusters:

kmeans5 = KMeans(n_clusters=5, random_state=1)

kmeans5.fit(X)

# check how many of the samples were correctly labeled
labels = kmeans5.labels_

correct_labels = sum(y == labels)
print('Cluster', kmeans5)
print("Result: %d out of %d samples were correctly labeled." % (correct_labels, y.size))
print('Accuracy score: {0:0.2f}'. format(correct_labels/float(y.size)))


# In[21]:


# Cluster 6
kmeans6 = KMeans(n_clusters=6, random_state=1)

kmeans6.fit(X)

# check how many of the samples were correctly labeled
labels = kmeans6.labels_

correct_labels = sum(y == labels)
print('Cluster', kmeans6)
print("Result: %d out of %d samples were correctly labeled." % (correct_labels, y.size))
print('Accuracy score: {0:0.2f}'. format(correct_labels/float(y.size)))


# In[22]:



import scipy.cluster.hierarchy as sch
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans
from yellowbrick.cluster import KElbowVisualizer

dataset_scaled = StandardScaler().fit_transform(dataset.drop(['status_type'], axis=1))


model = KMeans()
visualize = KElbowVisualizer(model, k=(1,10))
visualize.fit(dataset_scaled)
visualize.poof()

