#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
# Reading the data into a variable.
dataset = pd.read_csv('C:\Users\hp\Desktop\Lambton-subjects-new-data\Big data\CBD-2214_5-GroupAssignment1\LifeExpectancyData.csv')
# Print the first few(default - 5) values of the data.
print('Head: \n', dataset.head())


# In[2]:


# Print the information about the data(data-types and objects)
dataset.info()


# In[3]:


# Print the outline of data(count, mean, min, max,etc) rounding to 3 decimal places.
print('Describe: \n', round(dataset.describe(), 3))


# In[5]:


import seaborn as sns
import matplotlib.pyplot as plt

# Plotting graph showing null elements
sns.heatmap(pd.isna(dataset))
plt.show()

# Return the non-redundant value from the set for the feature Year.
dataset['Year'].unique()

# Dropping the NaN or empty values, only those rows with minimum 17 non-NaN value column are retained.
dataset = dataset.dropna(thresh=17)
dataset.isna().sum().sort_values()


# In[6]:


# Data correlation
corr_data = dataset.corr()
print('Correlation: \n', corr_data)


# In[7]:


# Plot the correlation graph
plt.figure(figsize=(15, 12))
sns.heatmap(corr_data, annot=True)
plt.show()


# In[8]:


# Function for filling missing values.
def fill_mean(feature_name, data=dataset):
    data[feature_name].fillna(data[feature_name].mean(), inplace=True)


# Filling the null values with average value of column
features_miss = dataset.columns[dataset.isna().any()]
for feature in features_miss:
    fill_mean(feature_name=feature)

dataset.isnull().sum()

# Graph
sns.countplot(x='Status', data=dataset)
plt.show()


# In[9]:


# Average Life expectancy of different Status.
df_status = dataset.groupby('Status')
for sta,life in df_status:
    print(sta + ":" + str(life['Life expectancy '].mean()))


# In[10]:


#Print longest and shortest life expectany in top 10 countries

print('Top 10 developed countries with the longest life expectancy')
status_data = dataset[dataset.Status == 'Developed'].groupby('Country')
print(status_data['Life expectancy '].mean().sort_values(ascending=False).head(10))
print('*' * 50)
print('Top 10 countries with the longest life expectancy')
data_count = dataset.groupby('Country')
print(data_count['Life expectancy '].mean().sort_values(ascending=False).head(10))
print('*' * 50)
print('Top 10 countries with the shortest life expectancy')
print(data_count['Life expectancy '].mean().sort_values(ascending=False).tail(10))
print('*' * 50)


# In[11]:


# Plotting the graph for longest and shortest Life expectancy in top 10 countries.

data_ed = status_data['Life expectancy '].mean().sort_values(ascending=False).head(10)
data_display = {'Country': data_ed.index, 'Life expectancy ': data_ed.values}
data_ed = pd.DataFrame(data_display)
data_long = data_count['Life expectancy '].mean().sort_values(ascending=False).head(10)
data_display = {'Country': data_long.index, 'Life expectancy ': data_long.values}
data_long = pd.DataFrame(data_display)
data_short = data_count['Life expectancy '].mean().sort_values(ascending=False).tail(10)
data_display = {'Country': data_short.index, 'Life expectancy ': data_short.values}
data_short = pd.DataFrame(data_display)
for df in [data_ed, data_long, data_short]:
    sns.barplot(x='Life expectancy ', y='Country', data=df)
    plt.show()


# In[12]:


y = dataset['Life expectancy ']
# Setting Life Expectancy as the recurring y-axis for graph plotting.
X = dataset.drop('Life expectancy ', axis=1)
X.head()

# Dividing data by the Developing and Developed statuses.
for features in X.columns:
    if features == 'Status':
        pass
    else:
        sns.scatterplot(x=X[features], y=y, hue=X['Status'])
        plt.legend()
        plt.show()


# In[13]:


from sklearn.preprocessing import LabelEncoder

# Converting parameters into numerical values for calculations
le = LabelEncoder()
X['Country'] = le.fit_transform(X['Country'])
X['Year'] = le.fit_transform(X['Year'])

status_dum = pd.get_dummies(X['Status'])
X.drop(columns='Status', inplace=True)
# X.head(3)
X = pd.concat([X, status_dum], axis=1)
X.head(3)


# In[19]:


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
import numpy as np

# Training and Testing of Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=101)

forest = RandomForestRegressor()
linear = LinearRegression()

forest.fit(X_train, y_train)
linear.fit(X_train, y_train)

# Print Score from test data.
print('Random Forest Regressor score is' , forest.score(X_test,y_test) * 100)
print('Linear regression score is:', linear.score(X_test, y_test) * 100)

y_predict_forest = np.array(forest.predict(X_test))
y_predict_linear = np.array(linear.predict(X_test))
y_test = np.array(y_test)


# In[20]:


from sklearn.metrics import mean_squared_error

# Print MSE
print('Random Forest Mean Squared error: ', mean_squared_error(y_test,y_predict_forest)**(0.5))
print('Linear Regression Mean Squared error: ', mean_squared_error(y_test,y_predict_linear)**(0.5))


# In[ ]:




