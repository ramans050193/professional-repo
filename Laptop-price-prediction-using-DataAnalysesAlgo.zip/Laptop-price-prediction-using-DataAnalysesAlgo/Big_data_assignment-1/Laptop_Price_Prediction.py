# Importing required modules and data

import pandas as pd

# import sklearn as sk

data_frame = pd.read_csv('LaptopPricePrediction.csv')
data_frame.head()

# removing the Unnamed column
data_frame.drop(data_frame.columns[data_frame.columns.str.contains('unnamed', case=False)], axis=1, inplace=True)
data_frame.head()

# removing the rupee symbol from the price column
data_frame['Price'] = data_frame['Price'].str.replace(',', '')
data_frame['Price'] = data_frame['Price'].str.replace('₹', '')
data_frame.head(10)

# removing the text the from the all rows of the ram column,so that we can treat it as number data.
data_frame["RAM"] = data_frame.RAM.str.replace('\s.*', '')

data_frame.head(10)

# removing the text the from the all rows of the Warranty column.
# so that we can treat it as number data.
data_frame["Warranty"] = data_frame.Warranty.str.replace('\s.*', '')
data_frame.head()

# droping irrelevant column such as operating system. Becuase it is same for every laptop.
# droping rating becuase it is no where correlated with price.

data_frame.drop(['rating', 'Operating System'], axis=1, inplace=True)
data_frame.head()

data_frame["Price"] = data_frame["Price"].astype(str).astype(int)
print(data_frame.dtypes)
data_frame['Storage'] = data_frame['Storage'].replace('1 TB', '1024 GB', regex=True)
data_frame

# O means python objects
# Working on data having data type object

column = [Predictor for Predictor in data_frame.columns if data_frame[Predictor].dtype == 'O']
for Predictor in column:
    labels_ordered = data_frame.groupby([Predictor])['Price'].mean().sort_values().index
    labels_ordered = {k: i for i, k in enumerate(labels_ordered, 0)}
    data_frame[Predictor] = data_frame[Predictor].map(labels_ordered)
data_frame.head(10)
from matplotlib import pyplot as plt

plt.hist(data_frame.Price)
plt.title("Price histogram")
plt.show()
plt.hist(data_frame.RAM)
plt.title("RAM histogram")
plt.show()
plt.hist(data_frame.Display)
plt.title("Display histogram")
plt.show()
plt.scatter(data_frame.RAM, data_frame.Price)
plt.title("Price vs RAM")
plt.show()
plt.scatter(data_frame.Processor, data_frame.Price)
plt.title("Price vs Processor")
plt.show()
plt.scatter(data_frame.Display, data_frame.Price)
plt.title("Price vs Display")
plt.show()
plt.scatter(data_frame.Processor * data_frame.RAM, data_frame.Price)
plt.title("Price vs Proc*RAM")
plt.show()
plt.scatter(data_frame.Processor * data_frame.RAM * data_frame.Name, data_frame.Price)
plt.title("Price vs Proc*RAM*Name")
plt.show()

# seprating target varaible from features
Target = data_frame['Price']
features = data_frame.drop(columns='Price')

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

a = scaler.fit_transform(features)
features = pd.DataFrame(a)
# features.head(10)

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(features, Target, test_size=0.3, random_state=42, shuffle=True)

from sklearn.ensemble import RandomForestRegressor

Random_forest_regressor = RandomForestRegressor(random_state=10)
Random_forest_regressor.fit(X_train, y_train)

print("Training score")
print(Random_forest_regressor.score(X_train, y_train))
print('\r')
print("Testing score accuracy")
print(Random_forest_regressor.score(X_test, y_test))
